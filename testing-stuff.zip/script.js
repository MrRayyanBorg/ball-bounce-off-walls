lol = true
var playerX = 30
var playerY = 30
function setup(){
  createCanvas(600,400);

}

function draw(){
  background(200,0,0)
  test()
}

function test(){
  var player = ellipse(playerX,playerY,30,30);
  if(lol == true){
    playerX = playerX +10;
    playerY = playerY +6;
    if(playerX+30 > 600 || playerY+30>400){
      lol = false
    }
  }
  if (lol == false){
    playerX = playerX -10;
    playerY = playerY -6;
    if(playerX-30 < 0 || playerY-30<0){
      lol = true
    }
  }
}


//EXERCISE 1
/*
let num = prompt("insert an number greater than 30 but less than 40")
try{
  if(isNaN(num) == true){
    throw "Not a number"
  }else{
    if(num<31){
      throw "Please enter a number greater than 30"
    }else if(num>39){
      throw "please enter a number less than 40"
    }else{
      throw "thank you - input accepted"
    }
  }
}catch(error){
  alert(error)
}
*/
/*
//EXERCISE 2
function promptDirection(question){
  let result = prompt(question);
  if result.toLocaleLowerCase() == "left") return "L";
  if result.toLocaleLowerCase() == "right") return "R";
  throw new Error("Invalid direction: " + result)
}

function look(){
  if (promptDirection("Which way?") == "L") {
    return "a house";
  } else {
    return "two angry bears";
  }
}

try{
  console.log("You see", look());
} catch (e)
*/